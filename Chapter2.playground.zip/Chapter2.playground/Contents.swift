import UIKit
import PlaygroundSupport

 class ViewController : UIViewController {
    var worldMainView : UIImageView!
    var world : UIImage!
    var dino: UIImage!
    var mDragone : UIImage!
    var fire : UIImage!

    override func loadView() {
        let myView = UIView()
       
        let worldMainView = UIImageView()
        worldMainView.frame = CGRect(x: 0, y: 0, width: 800, height: 800)
        world = UIImage(named: "world.jpg")
        worldMainView.image = world
        
        let dinoView = UIImageView()
        dinoView.frame = CGRect(x: 30, y: 390, width: 100, height: 70)
        dino = UIImage(named: "dino.png")
        dinoView.image = dino
        
        let mDragoneView = UIImageView()
        mDragoneView.frame = CGRect(x: 130, y: 80, width: 250, height: 250)
        mDragone = UIImage(named: "mDragone.png")
        mDragoneView.image = mDragone
        
        let fireView = UIImageView()
        fireView.frame = CGRect(x: 170, y: 245, width: 140, height: 140)
        fire = UIImage (named: "fire.png")
        fireView.image = fire
        
        let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 0.08
        animation.repeatCount = 4
        animation.autoreverses = true
        animation.fromValue = NSValue(cgPoint: CGPoint(x: mDragoneView.center.x - 10, y: mDragoneView.center.y))
        animation.toValue = NSValue(cgPoint: CGPoint(x: mDragoneView.center.x + 10, y: mDragoneView.center.y))
        mDragoneView.layer.add(animation, forKey: "position")
        
        let anim = CABasicAnimation(keyPath: "position")
        let myDelay = 0.09
        anim.duration = 0.08
        anim.repeatCount = 4
        anim.autoreverses = true
        anim.fromValue = NSValue(cgPoint: CGPoint(x: dinoView.center.x - 10, y: dinoView.center.y))
        anim.toValue = NSValue(cgPoint: CGPoint(x: dinoView.center.x + 10, y: dinoView.center.y))
        anim.beginTime = CACurrentMediaTime() + myDelay
        dinoView.layer.add(anim, forKey: "position")
        
        myView.addSubview(worldMainView)
        myView.addSubview(dinoView)
        myView.addSubview(mDragoneView)
        myView.addSubview(fireView)
        self.view = myView
    }
}

let viewController = ViewController()

PlaygroundPage.current.liveView = viewController
PlaygroundPage.current.needsIndefiniteExecution = true



    
